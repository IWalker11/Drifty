import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif', backgroundColor: '#111', color: '#fff' }}>
      <h1>Drifty</h1>
      <p>Welcome to the demo site for Drifty – a modern catering and mobile food cart brand.</p>
    </div>
  );
}

export default App;
